_This file is auto-generated. To update, make the changes in the pkg/i18n directory and then run `go generate ./...` from the project root._

# Lazygit 按键绑定

## 全局键绑定

| Key | Action | Info |
|-----|--------|-------------|
| `` <ctrl+r> `` | 切换到最近的仓库 |  |
| `` <pgup>, K, <ctrl+u> (fn+up/shift+k) `` | 向上滚动主面板 |  |
| `` <pgdown>, J, <ctrl+d> (fn+down/shift+j) `` | 向下滚动主面板 |  |
| `` @ `` | 打开命令日志菜单 | 查看命令日志的选项，例如显示/隐藏命令日志以及聚焦命令日志 |
| `` P `` | 推送 | Push the current branch to its upstream branch. If no upstream is configured, you will be prompted to configure an upstream branch. If other branches are stacked below the current one and have commits to push, you are offered to push those too. |
| `` p `` | 拉取 | Pull changes from the remote for the current branch. If no upstream is configured, you will be prompted to configure an upstream branch. If other branches are stacked below the current one and have changed on the remote, you are offered to update those too. |
| `` ) `` | 提高重命名相似度阈值 | 提高将删除和添加对视为重命名所需的相似度阈值。<br><br>默认值可在配置文件中通过键 'git.renameSimilarityThreshold' 更改。 |
| `` ( `` | 降低重命名相似度阈值 | 降低将删除和添加对视为重命名所需的相似度阈值。<br><br>默认值可在配置文件中通过键 'git.renameSimilarityThreshold' 更改。 |
| `` } `` | 扩大差异视图中显示的上下文范围 | 增加差异视图中变更周围显示的上下文量。<br><br>默认值可在配置文件中通过键 'git.diffContextSize' 更改。 |
| `` { `` | 缩小差异视图中显示的上下文范围 | 减少差异视图中变更周围显示的上下文量。<br><br>默认值可在配置文件中通过键 'git.diffContextSize' 更改。 |
| `` : `` | 执行 Shell 命令 | 调出可输入shell命令执行的提示符。 |
| `` <ctrl+p> `` | 查看自定义补丁选项 |  |
| `` m `` | 查看合并/变基选项 | 查看当前合并或变基的中止、继续、跳过选项 |
| `` R `` | 刷新 | 刷新Git状态（即在后台运行`git status`、`git branch`等命令以更新面板内容）。此操作不会执行`git fetch`。 |
| `` + `` | 下一屏模式(正常/半屏/全屏) |  |
| `` _ `` | 上一屏模式 |  |
| `` \| `` | Cycle diff renderers | Choose the next renderer in the list of configured diff renderers. |
| `` \ `` | Cycle diff renderers (reverse) | Choose the previous renderer in the list of configured diff renderers. |
| `` <ctrl+g> `` | Jump to file in diff | Pick one of the files of the diff shown in the main view, and scroll the main view to it. The focus stays in this panel. |
| `` <esc> `` | 取消 |  |
| `` ? `` | 打开菜单 |  |
| `` <ctrl+s> `` | 查看按路径过滤选项 | 查看用于过滤提交日志的选项，以便仅显示与过滤器匹配的提交。 |
| `` W, <ctrl+e> `` | 打开 diff 菜单 | 查看与比较两个引用相关的选项，例如与选定的 ref 进行比较，输入要比较的 ref，然后反转比较方向。 |
| `` q, <ctrl+c> `` | 退出 |  |
| `` <ctrl+z> `` | 挂起应用程序 |  |
| `` <ctrl+w> `` | 切换是否在差异视图中显示空白字符差异 | 切换是否在差异视图中显示空白字符更改。<br><br>默认值可在配置文件中通过键 'git.ignoreWhitespaceInDiffView' 更改。 |
| `` <alt+shift+c> `` | 编辑配置文件 | 使用外部编辑器打开文件 |
| `` z `` | 撤销 | Reflog将用于确定运行哪个git命令来撤消最后一个git命令。这并不包括对工作树的更改，只考虑提交。 |
| `` Z `` | 重做 | Reflog将用于确定运行哪个git命令来重做上一个git命令。这并不包括对工作树的更改，只考虑提交。 |

## 列表面板导航

| Key | Action | Info |
|-----|--------|-------------|
| `` , `` | 上一页 |  |
| `` . `` | 下一页 |  |
| `` <, <home> `` | 滚动到顶部 |  |
| `` >, <end> `` | 滚动到底部 |  |
| `` v `` | 切换拖动选择 |  |
| `` <shift+down> `` | 向下扩展选择范围 |  |
| `` <shift+up> `` | 向上扩展选择范围 |  |
| `` / `` | 开始搜索 |  |
| `` H `` | 向左滚动 |  |
| `` L `` | 向右滚动 |  |
| `` ] `` | 下一个标签 |  |
| `` [ `` | 上一个标签 |  |

## 子提交

| Key | Action | Info |
|-----|--------|-------------|
| `` <ctrl+o> `` | 复制缩略提交哈希值到剪贴板 |  |
| `` <space> `` | 检出 | 检出所选择的提交作为分离HEAD。 |
| `` y `` | 复制提交属性到剪贴板 | 复制提交属性到剪贴板(如hash、URL、diff、消息、作者)。 |
| `` o `` | 在浏览器中打开提交 |  |
| `` n `` | 从提交创建新分支 |  |
| `` N `` | 移动提交至新分支 | 创建一个新分支，并将当前分支未推送的提交移动到该分支。如果您打算开始新工作但忘记先创建新分支，这会很有用。<br><br>请注意，此操作忽略选择，新分支总是从主分支创建或堆叠在当前分支之上（您可以选择哪种方式）。 |
| `` w `` | 新建工作树 |  |
| `` g `` | 查看重置选项 | 查看重置选项 (soft/mixed/hard) 用于重置到选择项 |
| `` C `` | 复制提交(拣选) | 标记提交为已复制。然后，在本地提交视图中，您可以按 `V` (Cherry-Pick) 将已复制的提交粘贴到已检出的分支中。任何时候都可以按 `<esc>` 来取消选择。 |
| `` <ctrl+r> `` | 重置已拣选(复制)的提交 |  |
| `` <ctrl+t> `` | 使用外部差异比较工具(git difftool) |  |
| `` * `` | 选择当前分支的提交 |  |
| `` 0 `` | 聚焦主视图 |  |
| `` <enter> `` | 查看提交的文件 |  |
| `` / `` | 开始搜索 |  |

## 子模块

| Key | Action | Info |
|-----|--------|-------------|
| `` <ctrl+o> `` | 复制子模块名称到剪贴板 |  |
| `` <enter> `` | 进入 | 输入子模块 |
| `` d `` | 删除 | 删除选定的子模块及其相应的目录 |
| `` u `` | 更新 | 更新子模块 |
| `` n `` | 添加新的子模块 |  |
| `` e `` | 更新子模块 URL |  |
| `` i `` | 初始化 | 初始化子模块 |
| `` b `` | 查看批量子模块选项 |  |
| `` / `` | 通过文本过滤当前视图 |  |

## 工作区

| Key | Action | Info |
|-----|--------|-------------|
| `` n `` | 新建工作树 |  |
| `` <space> `` | 切换 | 切换到选中的工作树 |
| `` o `` | 在编辑器中编写 |  |
| `` d `` | 删除 | 删除选定的工作树。这将删除工作树的目录以及 .git 目录中有关工作树的元数据。 |
| `` / `` | 通过文本过滤当前视图 |  |

## 引用日志

| Key | Action | Info |
|-----|--------|-------------|
| `` <ctrl+o> `` | 复制缩略提交哈希值到剪贴板 |  |
| `` <space> `` | 检出 | 检出所选择的提交作为分离HEAD。 |
| `` y `` | 复制提交属性到剪贴板 | 复制提交属性到剪贴板(如hash、URL、diff、消息、作者)。 |
| `` o `` | 在浏览器中打开提交 |  |
| `` n `` | 从提交创建新分支 |  |
| `` N `` | 移动提交至新分支 | 创建一个新分支，并将当前分支未推送的提交移动到该分支。如果您打算开始新工作但忘记先创建新分支，这会很有用。<br><br>请注意，此操作忽略选择，新分支总是从主分支创建或堆叠在当前分支之上（您可以选择哪种方式）。 |
| `` w `` | 新建工作树 |  |
| `` g `` | 查看重置选项 | 查看重置选项 (soft/mixed/hard) 用于重置到选择项 |
| `` C `` | 复制提交(拣选) | 标记提交为已复制。然后，在本地提交视图中，您可以按 `V` (Cherry-Pick) 将已复制的提交粘贴到已检出的分支中。任何时候都可以按 `<esc>` 来取消选择。 |
| `` <ctrl+r> `` | 重置已拣选(复制)的提交 |  |
| `` <ctrl+t> `` | 使用外部差异比较工具(git difftool) |  |
| `` * `` | 选择当前分支的提交 |  |
| `` 0 `` | 聚焦主视图 |  |
| `` <enter> `` | 查看提交 |  |
| `` / `` | 通过文本过滤当前视图 |  |

## 提交

| Key | Action | Info |
|-----|--------|-------------|
| `` <ctrl+o> `` | 复制缩略提交哈希值到剪贴板 |  |
| `` <ctrl+r> `` | 重置已拣选(复制)的提交 |  |
| `` b `` | 查看二分查找选项 |  |
| `` s `` | 压缩(Squash) | 将已选提交压缩到该提交之下。这些选定的提交的消息会附加到该提交的消息之下。 |
| `` f `` | 修正 （fixup） | 将选定的提交合并到其下面的提交中。与压缩类似，但所选提交的消息将被丢弃。 |
| `` c `` | 设置修复提交信息 | 设置修复提交的信息选项。-C 选项表示使用此提交的信息，而非目标提交的信息。 |
| `` r `` | 改写提交 | 重写所选提交的消息。 |
| `` R `` | 使用编辑器重命名提交 |  |
| `` d `` | 删除提交 | 删除选中的提交。这将通过变基从分支中删除该提交，如果该提交修改的内容依赖于后续的提交，则需要解决合并冲突。 |
| `` e `` | 编辑(开始交互式变基) | 编辑提交 |
| `` i `` | 开始交互式变基 | 为分支上的提交启动交互式变基。这将包括从 HEAD 提交到第一个合并提交或主分支提交的所有提交。<br>如果您想从所选提交启动交互式变基，请按 `e`。 |
| `` p `` | 拣选(Pick) | 标记选中的提交为 picked（变基过程中）。这意味该提交将在后续的变基中保留。 |
| `` F `` | 为此提交创建修正 | 创建修正提交 |
| `` S `` | 应用该修复提交 | 压缩所选提交之上或当前分支的所有 “fixup!” 提交（自动压缩）。 |
| `` <ctrl+j>, <alt+down> `` | 下移提交 |  |
| `` <ctrl+k>, <alt+up> `` | 上移提交 |  |
| `` V `` | 粘贴提交(拣选) |  |
| `` B `` | 标记一个主提交用于变基 | 选择下一次变基的主提交。当您变基到一个分支时，只有高于主提交的提交才会被引入。这使用“git rebase --onto”命令。 |
| `` A `` | 修补(Amend) | 用已暂存的变更来修补提交 |
| `` a `` | 修补提交属性 | 设置或重置提交的作者，或添加其他作者。 |
| `` t `` | 撤销(Revert) | 为所选提交创建还原提交，这会反向应用所选提交的更改。 |
| `` T `` | 标签提交 | 创建一个新标签指向所选提交。您可以在弹窗中输入标签名称和描述(可选)。 |
| `` <ctrl+l> `` | 打开日志菜单 | 查看提交日志的选项，例如更改排序顺序、隐藏 git graph、显示整个 git graph。 |
| `` G `` | 在浏览器中打开拉取请求 |  |
| `` <space> `` | 检出 | 检出所选择的提交作为分离HEAD。 |
| `` y `` | 复制提交属性到剪贴板 | 复制提交属性到剪贴板(如hash、URL、diff、消息、作者)。 |
| `` o `` | 在浏览器中打开提交 |  |
| `` n `` | 从提交创建新分支 |  |
| `` N `` | 移动提交至新分支 | 创建一个新分支，并将当前分支未推送的提交移动到该分支。如果您打算开始新工作但忘记先创建新分支，这会很有用。<br><br>请注意，此操作忽略选择，新分支总是从主分支创建或堆叠在当前分支之上（您可以选择哪种方式）。 |
| `` w `` | 新建工作树 |  |
| `` g `` | 查看重置选项 | 查看重置选项 (soft/mixed/hard) 用于重置到选择项 |
| `` C `` | 复制提交(拣选) | 标记提交为已复制。然后，在本地提交视图中，您可以按 `V` (Cherry-Pick) 将已复制的提交粘贴到已检出的分支中。任何时候都可以按 `<esc>` 来取消选择。 |
| `` <ctrl+t> `` | 使用外部差异比较工具(git difftool) |  |
| `` * `` | 选择当前分支的提交 |  |
| `` 0 `` | 聚焦主视图 |  |
| `` <enter> `` | 查看提交的文件 |  |
| `` / `` | 开始搜索 |  |

## 提交信息

| Key | Action | Info |
|-----|--------|-------------|
| `` <enter> `` | 确认 |  |
| `` <esc> `` | 关闭 |  |

## 提交文件

| Key | Action | Info |
|-----|--------|-------------|
| `` <ctrl+o> `` | 复制路径到剪贴板 |  |
| `` y `` | 复制到剪贴板 |  |
| `` c `` | 检出 | 检出文件 |
| `` d `` | 查看'放弃变更'选项 | 放弃对此文件的提交变更 |
| `` o `` | 打开文件 | 使用默认程序打开该文件 |
| `` e `` | 编辑(Edit) | 使用外部编辑器打开文件 |
| `` <ctrl+t> `` | 使用外部差异比较工具(git difftool) |  |
| `` <space> `` | 补丁中包含的切换文件 | 切换文件是否包含在自定义补丁中。请参阅 https://github.com/jesseduffield/lazygit#rebase-magic-custom-patches。 |
| `` a `` | 操作所有文件 | 添加或删除所有提交中的文件到自定义的补丁中。请参阅 https://github.com/jesseduffield/lazygit#rebase-magic-custom-patches。 |
| `` <enter> `` | Focus file diff / Toggle directory | If a file is selected, focus its diff so you can act on individual lines. If it is a directory, collapse or expand it. |
| `` ` `` | 切换文件树视图 | 在平面布局和树布局之间切换文件视图。平面布局在单个列表中显示所有文件路径，树布局按目录分组文件。<br><br>可以在配置文件中使用 'gui.showFileTree' 键更改默认设置。 |
| `` - `` | 折叠全部文件 | 折叠文件树中的全部目录 |
| `` = `` | 展开全部文件 | 展开文件树中的全部目录 |
| `` 0 `` | 聚焦主视图 |  |
| `` / `` | 通过文本过滤当前视图 |  |

## 文件

| Key | Action | Info |
|-----|--------|-------------|
| `` <ctrl+o> `` | 复制路径到剪贴板 |  |
| `` <space> `` | 切换暂存状态 | 为选定的文件切换暂存状态 |
| `` <ctrl+b> `` | 通过状态过滤文件 |  |
| `` y `` | 复制到剪贴板 |  |
| `` c `` | 提交变更 | 提交暂存文件 |
| `` w `` | 提交变更而无需预先提交钩子 |  |
| `` A `` | 修补最后一次提交 |  |
| `` C `` | 使用 Git 编辑器提交变更 |  |
| `` <ctrl+f> `` | 找到用于修复的基准提交 | 找到您当前变更所基于的提交，以便于修正/改进该提交。这样做可以省去您逐一查看分支提交来确定应该修正/改进哪个提交的麻烦。请参阅文档: <https://github.com/jesseduffield/lazygit/tree/master/docs/Fixup_Commits.md> |
| `` e `` | 编辑(Edit) | 使用外部编辑器打开文件 |
| `` o `` | 打开文件 | 使用默认程序打开该文件 |
| `` i `` | 忽略文件 |  |
| `` r `` | 刷新文件 |  |
| `` s `` | 贮藏 | 贮藏所有变更.若要使用其他贮藏变体,请使用查看贮藏选项快捷键 |
| `` S `` | 查看贮藏选项 | 查看贮藏选项（例如：贮藏所有、贮藏已暂存变更、贮藏未暂存变更） |
| `` a `` | 切换所有文件的暂存状态 | 切换工作区中所有文件的已暂存/未暂存状态 |
| `` <enter> `` | Focus file diff / Collapse directory | If the selected item is a file, focus its diff so you can act on individual hunks or lines. If it is a directory, collapse or expand it. |
| `` d `` | 查看'放弃变更'选项 | 查看选中文件的放弃变更选项 |
| `` g `` | 查看上游重置选项 |  |
| `` D `` | 重置 | 查看工作树的重置选项（例如：清除工作树）。 |
| `` ` `` | 切换文件树视图 | 在平面布局和树布局之间切换文件视图。平面布局在单个列表中显示所有文件路径，树布局按目录分组文件。<br><br>可以在配置文件中使用 'gui.showFileTree' 键更改默认设置。 |
| `` <ctrl+t> `` | 使用外部差异比较工具(git difftool) |  |
| `` M `` | 查看合并冲突选项 | 查看用于解决合并冲突的选项。 |
| `` f `` | 抓取 | 从远程获取变更 |
| `` - `` | 折叠全部文件 | 折叠文件树中的全部目录 |
| `` = `` | 展开全部文件 | 展开文件树中的全部目录 |
| `` 0 `` | 聚焦主视图 |  |
| `` / `` | 通过文本过滤当前视图 |  |

## 本地分支

| Key | Action | Info |
|-----|--------|-------------|
| `` <ctrl+o> `` | 复制分支名称到剪贴板 |  |
| `` i `` | 显示 git-flow 选项 |  |
| `` <space> `` | 检出 | 检出选中的项目 |
| `` n `` | 新分支 |  |
| `` N `` | 移动提交至新分支 | 创建一个新分支，并将当前分支未推送的提交移动到该分支。如果您打算开始新工作但忘记先创建新分支，这会很有用。<br><br>请注意，此操作忽略选择，新分支总是从主分支创建或堆叠在当前分支之上（您可以选择哪种方式）。 |
| `` w `` | 新建工作树 |  |
| `` o `` | 创建拉取请求 |  |
| `` O `` | 创建拉取请求选项 |  |
| `` G `` | 在浏览器中打开拉取请求 |  |
| `` <ctrl+y> `` | 复制拉取请求 URL 到剪贴板 |  |
| `` c `` | 按名称检出 | 按名称检出。在输入框中，您可以输入'-' 来切换到最后一个分支。 |
| `` - `` | 签出上一个分支 |  |
| `` F `` | 强制检出 | 强制检出所选分支。这将在检出所选分支之前放弃工作目录中的所有本地更改。 |
| `` d `` | 删除 | 查看本地/远程分支的删除选项 |
| `` r `` | 变基 | 将检出的分支变基到所选的分支上。 |
| `` M `` | 合并到当前检出的分支 | 查看将选中项合并到当前分支的选项(正常合并，压缩合并) |
| `` f `` | 从上游快进此分支 | Fast-forward selected branch from its upstream. If the branch has diverged from its upstream because the upstream branch was rewritten, and it has no commits of its own, it is reset to its upstream instead. This needs reflogs to be enabled; a bare repository doesn't keep them by default (core.logAllRefUpdates). |
| `` T `` | 创建标签 |  |
| `` s `` | 排序 |  |
| `` g `` | 查看重置选项 |  |
| `` R `` | 重命名分支 |  |
| `` u `` | 查看上游选项 | 查看与分支上游相关的选项，例如设置/取消设置上游和重置为上游。 |
| `` <ctrl+t> `` | 使用外部差异比较工具(git difftool) |  |
| `` 0 `` | 聚焦主视图 |  |
| `` <enter> `` | 查看提交 |  |
| `` / `` | 通过文本过滤当前视图 |  |

## 标签

| Key | Action | Info |
|-----|--------|-------------|
| `` <ctrl+o> `` | 复制标签到剪贴板 |  |
| `` <space> `` | 检出 | 检出选择的标签作为分离的HEAD |
| `` n `` | 创建标签 | 基于当前提交创建一个新标签。您将在弹窗中输入标签名称和描述(可选)。 |
| `` w `` | 新建工作树 |  |
| `` d `` | 删除 | 查看本地/远程标签的删除选项 |
| `` P `` | 推送标签 | 推送选择的标签到远端。您将在弹窗中选择一个远端。 |
| `` g `` | 重置 | 查看重置选项 (soft/mixed/hard) 用于重置到选择项 |
| `` <ctrl+t> `` | 使用外部差异比较工具(git difftool) |  |
| `` 0 `` | 聚焦主视图 |  |
| `` <enter> `` | 查看提交 |  |
| `` / `` | 通过文本过滤当前视图 |  |

## 次要

| Key | Action | Info |
|-----|--------|-------------|
| `` <tab> `` | Switch diff pane | Switch to the other focused diff pane. |
| `` a `` | 切换代码块选择 | 切换逐行选择与代码块选择模式。 |
| `` v `` | 切换拖动选择 |  |
| `` e `` | 编辑文件 | 使用外部编辑器打开文件 |
| `` <space> `` | 切换暂存状态 | 切换行暂存状态 |
| `` d `` | 取消变更(git reset) | 当选择未暂存的变更时，使用git reset丢弃该变更。当选择已暂存的变更时，取消暂存该变更 |
| `` E `` | 编辑代码块 | 在外部编辑器中编辑选中的代码块 |
| `` <ctrl+o> `` | Copy selected diff lines to clipboard |  |
| `` <left>, h `` | 选择上一个区块 |  |
| `` <right>, l `` | 选择下一个区块 |  |
| `` N `` | Go to previous file |  |
| `` n `` | Go to next file |  |
| `` <ctrl+g> `` | Jump to file |  |
| `` G `` | Open pull request at selected line | Open the branch's pull request in your browser, at the line the selection is on, so that you can comment on it there. Only pull requests on GitHub are found. |
| `` <esc> `` | 退出回到侧边面板 |  |
| `` c `` | 提交变更 | 提交暂存文件 |
| `` w `` | 提交变更而无需预先提交钩子 |  |
| `` C `` | 使用 Git 编辑器提交变更 |  |
| `` <ctrl+f> `` | 找到用于修复的基准提交 | 找到您当前变更所基于的提交，以便于修正/改进该提交。这样做可以省去您逐一查看分支提交来确定应该修正/改进哪个提交的麻烦。请参阅文档: <https://github.com/jesseduffield/lazygit/tree/master/docs/Fixup_Commits.md> |
| `` / `` | 开始搜索 |  |

## 正在合并

| Key | Action | Info |
|-----|--------|-------------|
| `` <space> `` | 选中区块 |  |
| `` b `` | Pick both hunks |  |
| `` <up>, k `` | 选择顶部块 |  |
| `` <down>, j `` | 选择底部块 |  |
| `` <left>, h `` | 选择上一个冲突 |  |
| `` <right>, l `` | 选择下一个冲突 |  |
| `` z `` | 撤销 | 撤消上次合并冲突解决 |
| `` e `` | 编辑文件 | 使用外部编辑器打开文件 |
| `` o `` | 打开文件 | 使用默认程序打开该文件 |
| `` M `` | 查看合并冲突选项 | 查看用于解决合并冲突的选项。 |
| `` <esc> `` | 返回文件面板 |  |

## 正常

| Key | Action | Info |
|-----|--------|-------------|
| `` <mouse wheel down> (fn+up) `` | 向下滚动 |  |
| `` <mouse wheel up> (fn+down) `` | 向上滚动 |  |
| `` <tab> `` | Switch diff pane | Switch to the other focused diff pane. |
| `` a `` | 切换代码块选择 | 切换逐行选择与代码块选择模式。 |
| `` v `` | 切换拖动选择 |  |
| `` e `` | 编辑文件 | 使用外部编辑器打开文件 |
| `` <space> `` | 切换暂存状态 | 切换行暂存状态 |
| `` d `` | 取消变更(git reset) | 当选择未暂存的变更时，使用git reset丢弃该变更。当选择已暂存的变更时，取消暂存该变更 |
| `` E `` | 编辑代码块 | 在外部编辑器中编辑选中的代码块 |
| `` <ctrl+o> `` | Copy selected diff lines to clipboard |  |
| `` <left>, h `` | 选择上一个区块 |  |
| `` <right>, l `` | 选择下一个区块 |  |
| `` N `` | Go to previous file |  |
| `` n `` | Go to next file |  |
| `` <ctrl+g> `` | Jump to file |  |
| `` G `` | Open pull request at selected line | Open the branch's pull request in your browser, at the line the selection is on, so that you can comment on it there. Only pull requests on GitHub are found. |
| `` <esc> `` | 退出回到侧边面板 |  |
| `` c `` | 提交变更 | 提交暂存文件 |
| `` w `` | 提交变更而无需预先提交钩子 |  |
| `` C `` | 使用 Git 编辑器提交变更 |  |
| `` <ctrl+f> `` | 找到用于修复的基准提交 | 找到您当前变更所基于的提交，以便于修正/改进该提交。这样做可以省去您逐一查看分支提交来确定应该修正/改进哪个提交的麻烦。请参阅文档: <https://github.com/jesseduffield/lazygit/tree/master/docs/Fixup_Commits.md> |
| `` / `` | 开始搜索 |  |

## 状态

| Key | Action | Info |
|-----|--------|-------------|
| `` e `` | 编辑配置文件 | 使用外部编辑器打开文件 |
| `` u `` | 检查更新 |  |
| `` <enter> `` | 切换到最近的仓库 |  |
| `` a `` | 显示/循环所有分支日志 |  |
| `` A `` | 显示/循环所有分支日志（反向） |  |
| `` 0 `` | 聚焦主视图 |  |

## 确认面板

| Key | Action | Info |
|-----|--------|-------------|
| `` <enter> `` | 确认 |  |
| `` <esc> `` | 关闭 |  |
| `` <ctrl+o> `` | 复制到剪贴板 |  |

## 菜单

| Key | Action | Info |
|-----|--------|-------------|
| `` <enter> `` | 执行 |  |
| `` <esc> `` | 关闭 |  |
| `` / `` | 通过文本过滤当前视图 |  |

## 贮藏

| Key | Action | Info |
|-----|--------|-------------|
| `` <space> `` | 应用 | 将贮藏项应用到您的工作目录。 |
| `` g `` | 应用并删除 | 将存储项应用到工作目录并删除存储项。 |
| `` d `` | 删除 | 从贮藏列表中删除该贮藏项 |
| `` n `` | 新分支 | 从选定的贮藏项创建一个新分支。这是通过 git 检查创建贮藏项的提交，从该提交创建一个新分支，然后将贮藏项作为附加提交应用到新分支来实现的。 |
| `` w `` | 新建工作树 |  |
| `` r `` | 重命名贮藏 |  |
| `` 0 `` | 聚焦主视图 |  |
| `` <enter> `` | 查看提交的文件 |  |
| `` / `` | 通过文本过滤当前视图 |  |

## 输入提示

| Key | Action | Info |
|-----|--------|-------------|
| `` <enter> `` | 确认 |  |
| `` <esc> `` | 关闭 |  |

## 远程

| Key | Action | Info |
|-----|--------|-------------|
| `` <enter> `` | 查看分支 |  |
| `` n `` | 添加新的远程仓库 |  |
| `` d `` | 删除 | 删除选中的远程。从远程跟踪远程分支的任何本地分支都不会受到影响。 |
| `` e `` | 编辑(Edit) | 编辑远程仓库 |
| `` f `` | 抓取 | 抓取远程仓库 |
| `` F `` | 添加复刻远程仓库 | 通过替换 origin URL 中的所有者来快速添加复刻远程仓库，并可选择从新远程仓库检出分支。 |
| `` / `` | 通过文本过滤当前视图 |  |

## 远程分支

| Key | Action | Info |
|-----|--------|-------------|
| `` <ctrl+o> `` | 复制分支名称到剪贴板 |  |
| `` <space> `` | 检出 | 基于当前选中的远程分支检出一个新的本地分支，或者将远程分支作分离的HEAD。 |
| `` n `` | 新分支 |  |
| `` w `` | 新建工作树 |  |
| `` M `` | 合并到当前检出的分支 | 查看将选中项合并到当前分支的选项(正常合并，压缩合并) |
| `` r `` | 变基 | 将检出的分支变基到所选的分支上。 |
| `` d `` | 删除 | 从远程删除远程分支。 |
| `` u `` | 设置为上游 | 设置为检出分支的上游 |
| `` s `` | 排序 |  |
| `` g `` | 查看重置选项 | 查看重置选项 (soft/mixed/hard) 用于重置到选择项 |
| `` <ctrl+t> `` | 使用外部差异比较工具(git difftool) |  |
| `` 0 `` | 聚焦主视图 |  |
| `` <enter> `` | 查看提交 |  |
| `` / `` | 通过文本过滤当前视图 |  |
