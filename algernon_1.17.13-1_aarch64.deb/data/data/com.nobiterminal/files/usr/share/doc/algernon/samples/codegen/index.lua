print(GenerateUniqueConfirmationCode())
