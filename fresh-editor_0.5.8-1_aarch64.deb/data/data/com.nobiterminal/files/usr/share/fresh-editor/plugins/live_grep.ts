/// <reference path="./lib/fresh.d.ts" />
import { gitCwdCandidate } from "./lib/git_repo.ts";

/**
 * Live Grep Plugin
 *
 * Project-wide search rendered as a centred floating overlay
 * (issue #1796). Search results stream in as the user types; arrow
 * keys navigate; Enter opens at the match location.
 *
 * Search backend is pluggable. The plugin ships three built-in
 * providers (ripgrep → git grep → grep) selected by priority on
 * each invocation; users and other plugins can register additional
 * providers via the exported plugin API:
 *
 *     const liveGrep = editor.getPluginApi("live-grep");
 *     liveGrep?.registerProvider({
 *       name: "fff",
 *       priority: 100,                     // higher wins
 *       isAvailable: async ({ machine, cwd }) => {
 *         const r = await machine.run("fff", ["--version"], cwd);
 *         return r.code === 0;
 *       },
 *       search: async (query, { machine, cwd, maxResults }) => {
 *         const r = await machine.run("fff", [query], cwd);
 *         return parseFFFOutput(r.stdout);
 *       },
 *     });
 *
 * A provider runs its commands on the `machine` it is handed: the searched
 * workspace's (its SSH host or container for a remote one). The provider
 * whose `isAvailable()` returns true with the highest priority is selected
 * on each Live Grep invocation; the result is cached for the duration of
 * the prompt. "All workspaces" probes each other workspace's machine too.
 */

import { Finder, parseGrepOutput, type SearchCancellation } from "./lib/finder.ts";
import { ackArgs, agArgs, gitGrepArgs, grepArgs, relativeUnder, rgArgs, type GrepArgOpts } from "./lib/grep_args.ts";
import { col, dropdown, raw, row, spacer, styledRow, toggle, wrappingRow } from "./lib/widgets.ts";
import { groupByWorkspace, orderWorkspaces, terminalRowName, type Workspace } from "./lib/workspace_groups.ts";
import { WindowMachines } from "./lib/window_machines.ts";

const editor = getEditor();

/** The data sources Universal Search can look in. `files` is the
 *  classic project-file grep; the others are opt-in scopes layered on
 *  top. Each enabled scope contributes tagged matches to one merged
 *  result list. See `docs/internal/global-search-ux.md`. `workspaces`
 *  is not a source but *which* workspaces the others look in: the
 *  current one, or every open one, grouped. */
type ScopeId = "files" | "ignored" | "buffers" | "terminals" | "diagnostics" | "workspaces";


// One Live Grep match. Mirrors the JSON shape ripgrep emits with
// `--line-number --column --no-heading`; built-in non-rg providers
// (git grep, grep) normalise to this shape via parseGrepOutput.
// `source` tags which scope produced the match so the result row can
// show a badge and (later) pick a scope-appropriate open action.
// Undefined means the classic file source (`files`).
interface GrepMatch {
  file: string;
  line: number;
  column: number;
  content: string;
  source?: ScopeId;
  /** A line on a terminal's screen, which is in no file: the terminal's
   *  buffer, shown when the match is picked. */
  bufferId?: number;
  /** The file to open when it is not `file` itself: a terminal's backing
   *  file (`file` is the terminal's name), or an unsaved edit's file. */
  openPath?: string;
  /** The workspace the match is in, when "All workspaces" is on. */
  workspace?: Workspace;
  /** Set on a group's header row (no match itself): the number of matches
   *  in `workspace` listed under it. */
  heading?: number;
  /** False when the preview would not show what matched (`previewable`). */
  preview?: boolean;
}

/** Where a provider runs: the searched workspace's machine, and its root. */
export interface ProviderContext {
  /** The workspace's machine (`openMachine({ kind: "window" })`): run every
   *  command on it, so a remote workspace is searched on its host. */
  machine: FreshMachine;
  /** The workspace's root: the directory to search. */
  cwd: string;
}

/** Options passed to a provider's `search` callback. */
export interface SearchOpts extends ProviderContext {
  /** Caller's preferred result cap. Providers may return fewer.
   *  Returning more is allowed; the Finder caps at its own
   *  `maxResults`. */
  maxResults: number;
  /** When true, the "Ignored & hidden" scope is on: providers should
   *  also search `.gitignore`d / hidden files. Built-in `rg`, `git-grep`
   *  and `ag` honour this, and `grep` drops its stand-in excludes; `ack`
   *  ignores it and always searches its default set. */
  includeIgnored?: boolean;
  /** `file_explorer.custom_ignore_patterns`: `.gitignore` lines, relative
   *  to `cwd`, naming what to leave out — the same list the file explorer
   *  and Quick Open honour. Empty when `includeIgnored` is on, since that
   *  scope searches everything but `.git`. Built-ins pass them as their
   *  closest exclude flags (see `lib/grep_args.ts`). */
  ignorePatterns?: string[];
  /** When true, match whole words only (rg `-w`, git-grep/grep `-w`).
   *  Providers should add the appropriate flag. */
  wholeWord?: boolean;
  /** When true (the default), the query is a regular expression; when
   *  false, it's a literal/fixed string the provider must escape (rg
   *  `-F`, git-grep/grep `-F`). Custom providers should honour this so
   *  the query is interpreted consistently with the toolbar toggle. */
  regex?: boolean;
  /** When true, match upper and lower case exactly; when false (the
   *  default) fold case. Providers must decide this *explicitly* — a
   *  smart-case flag left on would quietly re-derive it from the query
   *  and disagree with the Case toggle on the toolbar. Built-ins pass
   *  rg `--case-sensitive`/`--ignore-case`, git-grep/grep/ack `-i`. */
  caseSensitive?: boolean;
  /** Fires when the search is superseded by a newer query or the overlay
   *  closes: kill what you started (`runSearch` does it for you). */
  cancellation?: SearchCancellation;
}

/** Run a search command on `opts`' machine, killed when the search is
 *  cancelled rather than running on to completion unread. */
function runSearch(cmd: string, args: string[], cwd: string, opts: SearchOpts): ProcessHandle<CommandResult> {
  const process = opts.machine.run(cmd, args, cwd);
  opts.cancellation?.onCancel(() => process.kill());
  return process;
}

/** A registered Live Grep backend. */
export interface LiveGrepProvider {
  /** Stable id, surfaced in status messages. Two providers with the
   *  same name are both kept; only the higher-priority one is ever
   *  selected unless it becomes unavailable. */
  name: string;
  /** Higher priority wins. Built-ins use 0/-1/-2; user-registered
   *  providers default to 0 if omitted. */
  priority?: number;
  /** Cheap probe — typically `ctx.machine.run("foo", ["--version"],
   *  ctx.cwd)` and check `code`. May be sync or async. Failures (thrown
   *  errors) are treated as "not available". */
  isAvailable: (ctx: ProviderContext) => boolean | Promise<boolean>;
  /** Run the search. Return an array of matches; an empty array
   *  means "no matches" (not "provider broken"). Errors thrown
   *  here surface as a status message and bypass the next
   *  provider — the registry doesn't fall back automatically once
   *  a provider is selected. */
  search: (query: string, opts: SearchOpts) => Promise<GrepMatch[]>;
}

/** Public surface exposed via `editor.getPluginApi("live-grep")`. */
export type LiveGrepApi = {
  /** Add a provider. Returns an unregister function. */
  registerProvider(provider: LiveGrepProvider): () => void;
  /** Remove every provider whose name matches. Returns true if at
   *  least one was removed. */
  unregisterProvider(name: string): boolean;
  /** Inspect the current provider list, sorted by priority desc.
   *  Useful for status / debugging / settings UIs. */
  listProviders(): { name: string; priority: number }[];
  /** Forget the cached "selected provider" — the next search runs a
   *  fresh `isAvailable()` probe. Call from init.ts after late
   *  registrations or after the user installs a new binary. */
  resetSelection(): void;
};

declare global {
  interface FreshPluginRegistry {
    "live-grep": LiveGrepApi;
  }
}

// Cap on the number of matches a single search returns. Higher than
// the previous 100 to actually fit a typical refactor's worth of
// hits in one snapshot, but bounded so a runaway query doesn't
// stream the entire codebase into the overlay.
const MAX_RESULTS = 1000;

// ── Scopes (Universal Search) ─────────────────────────────────────
//
// Live Grep is growing into a one-stop search: the user toggles which
// data sources to look in from the overlay toolbar. `files` is the
// classic project grep; `ignored`, `buffers`, `diagnostics` layer on
// top. Toggles are wired through prompt-context keybindings (Alt+…)
// that resolve to the plugin handlers registered below — no core
// Action is required (the host dispatches unknown action names as
// plugin actions). See `docs/internal/global-search-ux.md`.

interface ScopeDef {
  id: ScopeId;
  /** i18n key for the toolbar label. */
  labelKey: string;
  /** Plugin action / handler name a keybinding resolves to. */
  action: string;
  /** Short badge shown on a result row from this scope (omitted for
   *  `files`, whose rows are the unprefixed default). */
  badge?: string;
}

const SCOPES: ScopeDef[] = [
  { id: "files", labelKey: "scope.files", action: "live_grep_toggle_files" },
  { id: "ignored", labelKey: "scope.ignored", action: "live_grep_toggle_ignored", badge: "ign" },
  { id: "buffers", labelKey: "scope.buffers", action: "live_grep_toggle_buffers", badge: "buf" },
  { id: "terminals", labelKey: "scope.terminals", action: "live_grep_toggle_terminals", badge: "term" },
  { id: "diagnostics", labelKey: "scope.diagnostics", action: "live_grep_toggle_diagnostics", badge: "diag" },
  { id: "workspaces", labelKey: "scope.workspaces", action: "live_grep_toggle_workspaces" },
];

// Default scope set: same as the classic Live Grep, *minus* ignored
// files (off — they were noisy) and *plus* unsaved open buffers and
// terminal scrollback (on). `files` on, `ignored` off, `buffers` on,
// `terminals` on, `diagnostics` off, and only this workspace
// (`workspaces` off). Like the match modes, a flip lasts the session.
const scopeEnabled: Record<ScopeId, boolean> = {
  files: true,
  ignored: false,
  buffers: true,
  terminals: true,
  diagnostics: false,
  workspaces: false,
};

// True only while our floating overlay is open. The scope-toggle
// keybindings live in the shared `prompt` context, so they can fire
// inside *any* prompt; the handlers no-op unless our overlay owns the
// screen.
let overlayActive = false;

// The most recent query, so Resume can re-open the *same* flow with it
// pre-filled (rather than a bespoke cached-results overlay).
let lastQuery = "";

// The most recent merged result set, captured by `search` so the
// Quickfix export can snapshot exactly what the user is looking at into
// the dock panel without re-running the search.
let lastResults: GrepMatch[] = [];

// ── Search modes ──────────────────────────────────────────────────
//
// Separate from *where* we search (scopes): these control *how* the
// query is interpreted, and are threaded to every provider (and the
// JS-side scopes) so each can escape/format it correctly. `regex` is
// on by default (matches the historical rg/git-grep behaviour);
// `wholeWord` is off, and so is `case` — a search for `todo` finds
// `TODO` until you say otherwise (issue #3212). The config preset
// `editor.search.case_sensitive` seeds `case` at load; flipping the
// toggle wins for the rest of the session.
//
// `case` replaces what used to be smart-case, where an uppercase
// letter anywhere in the query silently turned matching
// case-sensitive. Smart-case is a guess about intent that the user
// cannot see, let alone turn off; a toggle on the toolbar is the same
// decision, made visible and reversible.
type ModeId = "word" | "case" | "regex";

interface ModeDef {
  id: ModeId;
  /** Stable widget key for the toolbar toggle. */
  key: string;
  /** i18n key for the toggle label. */
  labelKey: string;
  /** Plugin action a keybinding resolves to (drives the inline accelerator
   *  and the Alt+… shortcut, like the scope toggles). */
  action: string;
}

const MODES: ModeDef[] = [
  { id: "word", key: "mode_word", labelKey: "mode.word", action: "live_grep_toggle_word" },
  { id: "case", key: "mode_case", labelKey: "mode.case", action: "live_grep_toggle_case" },
  { id: "regex", key: "mode_regex", labelKey: "mode.regex", action: "live_grep_toggle_regex" },
];

/** The `editor.search.case_sensitive` preset, read once at load. A
 *  missing or non-boolean value means "off", which is also the shipped
 *  default — this overlay never starts case-sensitive by accident. */
function configuredCaseSensitive(): boolean {
  const cfg = editor.getConfig() as
    | { editor?: { search?: { case_sensitive?: unknown } } }
    | null;
  return cfg?.editor?.search?.case_sensitive === true;
}

const searchModes: Record<ModeId, boolean> = {
  word: false,
  case: configuredCaseSensitive(),
  regex: true,
};

/** A compiled matcher for the diagnostics scope (message text).
 *  Returns the 1-based column of the first match on a line, or -1. */
type LineMatcher = (line: string) => number;

/** Build a line matcher honouring the current `searchModes` — including
 *  `case`, so the diagnostics scope matches exactly
 *  what the toolbar says and exactly what the grep backends are told.
 *  An invalid regex matches nothing (the provider scopes surface the
 *  rg/grep error; this scope just contributes no rows). */
function buildLineMatcher(query: string): LineMatcher {
  const foldCase = !searchModes.case;
  if (searchModes.regex) {
    const flags = foldCase ? "i" : "";
    const pattern = searchModes.word ? `\\b(?:${query})\\b` : query;
    let re: RegExp;
    try {
      re = new RegExp(pattern, flags);
    } catch {
      return () => -1;
    }
    return (line) => {
      const m = re.exec(line);
      return m ? m.index + 1 : -1;
    };
  }
  // Literal (fixed-string) matching.
  const needle = foldCase ? query.toLowerCase() : query;
  const isWord = (ch: string) => /[A-Za-z0-9_]/.test(ch);
  return (line) => {
    const hay = foldCase ? line.toLowerCase() : line;
    let from = 0;
    for (;;) {
      const idx = hay.indexOf(needle, from);
      if (idx < 0) return -1;
      if (!searchModes.word) return idx + 1;
      const before = idx > 0 ? hay[idx - 1] : "";
      const after = idx + needle.length < hay.length ? hay[idx + needle.length] : "";
      if (!isWord(before) && !isWord(after)) return idx + 1;
      from = idx + 1;
    }
  };
}

// ── Registry ──────────────────────────────────────────────────────

const providers: LiveGrepProvider[] = [];
let cachedSelected: LiveGrepProvider | null | undefined = undefined;
// Set by `search` after each query so the toolbar can show
// "1000+ matches" when a result set was clipped at MAX_RESULTS.
// Reset to false on every new query (before the provider call).
let lastSearchTruncated = false;

function sortByPriority(): void {
  providers.sort((a, b) => (b.priority ?? 0) - (a.priority ?? 0));
}

function registerProvider(provider: LiveGrepProvider): () => void {
  if (typeof provider !== "object" || provider === null) {
    throw new Error("live-grep.registerProvider: provider must be an object");
  }
  if (typeof provider.name !== "string" || provider.name.length === 0) {
    throw new Error("live-grep.registerProvider: name must be a non-empty string");
  }
  if (typeof provider.isAvailable !== "function") {
    throw new Error("live-grep.registerProvider: isAvailable must be a function");
  }
  if (typeof provider.search !== "function") {
    throw new Error("live-grep.registerProvider: search must be a function");
  }
  providers.push(provider);
  sortByPriority();
  cachedSelected = undefined; // re-probe on next invocation
  return () => {
    const i = providers.indexOf(provider);
    if (i >= 0) {
      providers.splice(i, 1);
      cachedSelected = undefined;
    }
  };
}

function unregisterProvider(name: string): boolean {
  let removed = false;
  for (let i = providers.length - 1; i >= 0; i--) {
    if (providers[i].name === name) {
      providers.splice(i, 1);
      removed = true;
    }
  }
  if (removed) cachedSelected = undefined;
  return removed;
}

// Build the toolbar as real widgets (themed, clickable, focusable), laid out
// as a small form: a label column (`Scope` / `Match` / `Provider`) and, beside
// it, the controls. Each toggle underlines its accelerator letter (the `l` of
// `Files` for Alt+L) instead of spelling `Alt+L` after it; a letter the label
// lacks (a rebound key, a translation) falls back to the spelled-out hint.
//
// The toggles sit in a `wrappingRow`, so a wide terminal gets one line per
// section and a narrow one reflows — and because that wrapping row is the
// second child of a row whose first child is the label column, continuation
// lines stay in the control column rather than returning to the edge.

/** The letter an `Alt+X`-style accelerator label names, lowercased; null
 *  for chords that are not a single modified letter. */
function accelLetter(accel: string | null): string | null {
  const m = accel?.match(/^Alt\+(\p{L}|\p{N})$/u);
  return m ? m[1].toLowerCase() : null;
}

/** `Match: ` → `Match` — translations carry their own trailing
 *  colon and spacing for the old inline layout; the column adds its own. */
function sectionName(key: string): string {
  return editor.t(key).replace(/[\s:：]+$/u, "");
}

/** The label column: every section label padded to the widest one (by
 *  display width, so CJK labels align too), plus a gutter. `underline`
 *  marks the label's own accelerator letter (Provider's `P`). */
function sectionLabel(text: string, width: number, underline?: string | null): WidgetSpec {
  const segs: StyledText[] = [{ text: "  " }];
  const at = underline ? text.toLowerCase().indexOf(underline) : -1;
  if (at >= 0) {
    const ch = [...text.slice(at)][0];
    segs.push(
      { text: text.slice(0, at), style: { fg: "ui.suggestion_fg" } },
      { text: ch, style: { fg: "ui.help_key_fg", underline: true } },
      { text: text.slice(at + ch.length), style: { fg: "ui.suggestion_fg" } },
    );
  } else {
    segs.push({ text, style: { fg: "ui.suggestion_fg" } });
  }
  segs.push({ text: " ".repeat(width - editor.stringWidth(text) + 3) });
  return raw([styledRow(segs)]);
}

/** One toggle plus, only when its accelerator letter is not in the label,
 *  the spelled-out `Alt+X` after it. Kept as one non-wrapping unit so the
 *  wrapping parent never separates a toggle from its hint. */
function toolbarToggle(checked: boolean, text: string, key: string, action: string): WidgetSpec {
  const accel = editor.getKeybindingLabel(action, "prompt");
  const letter = accelLetter(accel);
  if (letter && text.toLowerCase().includes(letter)) {
    return toggle(checked, text, { key, mnemonic: letter });
  }
  const parts: WidgetSpec[] = [toggle(checked, text, { key })];
  if (accel) {
    parts.push(raw([styledRow([{ text: ` ${accel}`, style: { fg: "ui.help_key_fg" } }])]));
  }
  return row(...parts);
}

/** The label column's width: the widest section label, the query row's
 *  `Search` included, so the query field lines up with the controls. */
function labelColumnWidth(): number {
  return Math.max(
    ...["label.search", "label.scope", "label.match", "label.provider"].map((k) =>
      editor.stringWidth(sectionName(k))
    ),
  );
}

/** The query row's prompt text: `Search` in the label column, padded the
 *  way `sectionLabel` pads the toolbar's labels, so the field starts in
 *  the same column as the toggles below it. The card's title already
 *  names the feature, so the row does not repeat it. */
function queryLabel(): string {
  const name = sectionName("label.search");
  return `  ${name}${" ".repeat(labelColumnWidth() - editor.stringWidth(name) + 3)}`;
}

function buildToolbarSpec(provider: LiveGrepProvider | null): WidgetSpec {
  const scopeName = sectionName("label.scope");
  const matchName = sectionName("label.match");
  const providerName = sectionName("label.provider");
  const width = labelColumnWidth();

  // The space between controls rides at the end of each one rather than as
  // a child of its own: a separate spacer that did not fit would wrap to the
  // start of the next line and push that line's first control off the column.
  const section = (name: string, controls: WidgetSpec[]): WidgetSpec => {
    const items = controls.map((c, i) => (i < controls.length - 1 ? row(c, spacer(2)) : c));
    return row(sectionLabel(name, width), wrappingRow(...items));
  };

  const matchSection = section(
    matchName,
    MODES.map((m) => toolbarToggle(searchModes[m.id], editor.t(m.labelKey), m.key, m.action)),
  );

  // Provider dropdown — only when a file-backed scope is on (irrelevant
  // when searching only buffers/terminals/diagnostics). Picking an entry
  // fires `change`; Alt+P still cycles without opening the list.
  //
  // It shares a wrapping row with the Match section: beside it when the
  // card is wide enough, otherwise on the line below, where its own label
  // lands in the label column. The gap rides at the end of the Match unit
  // (see `section`) so a wrapped Provider starts flush with the column.
  let lastRow: WidgetSpec = matchSection;
  const choices = providerChoices();
  if (choices.length > 0 && (scopeEnabled.files || scopeEnabled.ignored)) {
    const options = choices.map((p) => p.name);
    const selectedIndex = Math.max(0, provider ? choices.indexOf(provider) : 0);
    const pLetter = accelLetter(editor.getKeybindingLabel("cycle_live_grep_provider", "prompt"));
    lastRow = wrappingRow(
      row(matchSection, spacer(2)),
      row(
        sectionLabel(providerName, width, pLetter),
        dropdown(options, { selectedIndex, key: "provider" }),
      ),
    );
  }
  const rows: WidgetSpec[] = [
    section(
      scopeName,
      SCOPES.map((s) => toolbarToggle(scopeEnabled[s.id], editor.t(s.labelKey), s.id, s.action)),
    ),
    spacer(1),
    lastRow,
  ];
  return col(...rows);
}

/** The footer: the truncation indicator when the last result set was
 *  clipped, the save shortcut, and how the underlined letters work — in
 *  that order, so a narrow card clips the hint the underlines already
 *  suggest rather than the one nothing else on screen says. */
function buildFooter(): StyledText[] {
  const hintStyle = { fg: "ui.help_key_fg" };
  const sepStyle = { fg: "ui.popup_border_fg" };
  const parts: StyledText[][] = [];
  if (lastSearchTruncated) parts.push([{ text: `${MAX_RESULTS}+ matches` }]);
  const saveKey = editor.getKeybindingLabel("live_grep_export_quickfix", "prompt");
  if (saveKey) {
    parts.push([{ text: saveKey, style: hintStyle }, { text: ` ${editor.t("hint.save_matches")}` }]);
  }
  parts.push([{ text: editor.t("hint.mnemonics") }]);
  return parts.flatMap((p, i) => (i > 0 ? [{ text: "  ·  ", style: sepStyle }, ...p] : p));
}

// Refresh the overlay chrome: the card title, the toolbar (header band) and
// the footer hints. Name kept as `updateOverlayTitle` for its many call sites.
function updateOverlayTitle(provider: LiveGrepProvider | null): void {
  editor.setPromptTitle([{ text: sectionName("prompt.live_grep") }]);
  editor.setPromptToolbar(buildToolbarSpec(provider));
  editor.setPromptFooter(buildFooter());
}

// Last known `isAvailable()` answer per provider, so the dropdown can leave
// out the ones that cannot run. Filled by `probeProviders` (all of them, in the
// background, once per overlay) and by every probe `selectProvider` and
// `cycleProvider` make on their own.
const providerAvailable = new Map<string, boolean>();

/** Each window's machine, where its searches run (`lib/window_machines.ts`). */
const machines = new WindowMachines(editor);
editor.on("window_closed", ({ id }) => machines.close(id));

/** The current workspace, as a provider sees it. */
async function currentContext(): Promise<ProviderContext> {
  return { machine: await machines.get(editor.activeWindow()), cwd: editor.getCwd() };
}

/** Whether `p` can run in `ctx`'s workspace; a probe that throws cannot. */
async function canRun(p: LiveGrepProvider, ctx: ProviderContext): Promise<boolean> {
  try {
    return await Promise.resolve(p.isAvailable(ctx));
  } catch (e) {
    editor.debug(`[live-grep] ${p.name}.isAvailable threw: ${e}`);
    return false;
  }
}

/** Whether `p` can run in the current workspace, remembered for the
 *  dropdown. */
async function probeProvider(p: LiveGrepProvider): Promise<boolean> {
  let ok = false;
  try {
    ok = await canRun(p, await currentContext());
  } catch (e) {
    editor.debug(`[live-grep] no machine for the current workspace: ${e}`);
  }
  providerAvailable.set(p.name, ok);
  return ok;
}

async function probeProviders(): Promise<void> {
  const before = providers.map((p) => providerAvailable.get(p.name)).join();
  await Promise.all(providers.map(probeProvider));
  const after = providers.map((p) => providerAvailable.get(p.name)).join();
  if (overlayActive && before !== after) updateOverlayTitle(cachedSelected ?? null);
}

/** The providers the dropdown offers: every one not known to be unable to
 *  run. Listing an unavailable one would be a trap — the list's selection
 *  is live, so arrowing past it would try (and fail) to switch to it. */
function providerChoices(): LiveGrepProvider[] {
  return providers.filter((p) => providerAvailable.get(p.name) !== false);
}

/** Point the dropdown at `provider` without firing `change` — for when the
 *  selection moved some other way (Alt+P, a fallback). The toolbar is this
 *  plugin's widget panel 0. */
function syncProviderDropdown(provider: LiveGrepProvider | null): void {
  const index = provider ? providerChoices().indexOf(provider) : -1;
  if (index >= 0) {
    editor.widgetMutate(0, { kind: "setDropdown", widgetKey: "provider", index });
  }
}

/** The dropdown's `change`: switch to the picked provider, or — if it
 *  turns out it cannot run (not probed yet when the list was built) —
 *  drop it from the list, put the dropdown back and say why. */
async function pickProvider(index: number): Promise<void> {
  const candidate = providerChoices()[index];
  if (!candidate || candidate === cachedSelected) return;
  if (!(await probeProvider(candidate))) {
    updateOverlayTitle(cachedSelected ?? null);
    syncProviderDropdown(cachedSelected ?? null);
    editor.setStatus(`Live Grep: ${candidate.name} is not available`);
    return;
  }
  cachedSelected = candidate;
  await finder.refresh();
  editor.setStatus(`Live Grep: switched to ${candidate.name}`);
}

async function selectProvider(): Promise<LiveGrepProvider | null> {
  if (cachedSelected !== undefined) {
    updateOverlayTitle(cachedSelected);
    return cachedSelected;
  }
  for (const p of providers) {
    if (await probeProvider(p)) {
      cachedSelected = p;
      editor.debug(`[live-grep] selected provider: ${p.name}`);
      updateOverlayTitle(p);
      return p;
    }
  }
  cachedSelected = null;
  updateOverlayTitle(null);
  return null;
}

// ── Built-in providers ──────────────────────────────────────────

registerProvider({
  name: "rg",
  priority: -1,
  isAvailable: async ({ machine, cwd }) => (await machine.run("rg", ["--version"], cwd)).code === 0,
  search: async (query, opts) => {
    const { cwd, maxResults } = opts;
    const args = rgArgs(query, opts);
    const r = await runSearch("rg", args, cwd, opts);
    // 1 is "no matches", not a failure: throwing on it aborted the whole
    // search before buffers and terminals were searched
    if (r.code === 0 || r.code === 1) {
      return parseGrepOutput(r.stdout, maxResults, (msg) => editor.debug(msg)) as GrepMatch[];
    }
    throw new Error(`rg exited with code ${r.code}: ${r.stderr}`);
  },
});

registerProvider({
  name: "ag",
  priority: -2,
  isAvailable: async ({ machine, cwd }) => (await machine.run("ag", ["--version"], cwd)).code === 0,
  search: async (query, opts) => {
    const { cwd, maxResults } = opts;
    const args = agArgs(query, opts);
    const r = await runSearch("ag", args, cwd, opts);
    if (r.code === 0 || r.code === 1) {
      return parseGrepOutput(r.stdout, maxResults, (msg) => editor.debug(msg)) as GrepMatch[];
    }
    throw new Error(`ag exited with code ${r.code}: ${r.stderr}`);
  },
});

/** The cwd git-grep should run in: the caller's `preferred` cwd when it is
 *  itself inside a repo, else the active buffer's dir (monorepo: the workspace
 *  root isn't a repo but the open file is). Returns null when neither is a
 *  repo. Used by both `isAvailable` and `search` so they can't disagree. */
async function gitGrepCwd(machine: FreshMachine, preferred: string): Promise<string | null> {
  const inRepo = await machine.run("git", ["rev-parse", "--is-inside-work-tree"], preferred);
  if (inRepo.code === 0) return preferred;
  // The active buffer is in the current workspace: it says nothing about
  // another workspace ("All workspaces"), whose machine is its own.
  if (machine.id !== (await machines.get(editor.activeWindow())).id) return null;
  const cand = gitCwdCandidate(editor);
  if (cand !== preferred) {
    const r = await machine.run("git", ["rev-parse", "--is-inside-work-tree"], cand);
    if (r.code === 0) return cand;
  }
  return null;
}

registerProvider({
  name: "git-grep",
  // Top priority. git grep is the default *when available* — i.e.
  // when the working directory is inside a git repo with `git`
  // installed. `isAvailable` checks both, and outside a repo the
  // registry falls through to ripgrep / ag / ack / grep in order.
  priority: 0,
  isAvailable: async ({ machine, cwd }) => {
    // git grep needs both `git` on PATH and a repo to run in. Resolve
    // the repo cwd the *same way* search() does, so the two can never
    // disagree (availability said yes but search runs in a non-repo).
    const ver = await machine.run("git", ["--version"], cwd);
    if (ver.code !== 0) return false;
    return (await gitGrepCwd(machine, cwd)) !== null;
  },
  search: async (query, opts) => {
    const { cwd, maxResults } = opts;
    // Run in the same repo cwd isAvailable() confirmed. Null means the
    // context is no longer a repo — return empty rather than throwing.
    const gitCwd = await gitGrepCwd(opts.machine, cwd);
    if (!gitCwd) return [] as GrepMatch[];
    // The ignore patterns are relative to `cwd`; tell the builder where
    // the repo cwd sits below it so rooted ones can be rebased.
    const args = gitGrepArgs(query, opts, relativeUnder(cwd, gitCwd));
    const r = await runSearch("git", args, gitCwd, opts);
    // git grep exits 1 when no matches — treat as empty, not error.
    if (r.code === 0 || r.code === 1) {
      return parseGrepOutput(r.stdout, maxResults, (msg) => editor.debug(msg)) as GrepMatch[];
    }
    throw new Error(`git grep exited with code ${r.code}: ${r.stderr}`);
  },
});

registerProvider({
  name: "ack",
  priority: -3,
  // Note: ack/grep are kept at lower priority than ripgrep/ag/
  // git-grep because they're slower on large trees; the cycler
  // skips them automatically when a faster backend is available.
  isAvailable: async ({ machine, cwd }) => (await machine.run("ack", ["--version"], cwd)).code === 0,
  search: async (query, opts) => {
    const { cwd, maxResults } = opts;
    const args = ackArgs(query, opts);
    const r = await runSearch("ack", args, cwd, opts);
    if (r.code === 0 || r.code === 1) {
      return parseGrepOutput(r.stdout, maxResults, (msg) => editor.debug(msg)) as GrepMatch[];
    }
    throw new Error(`ack exited with code ${r.code}: ${r.stderr}`);
  },
});

// Note: `fff` is *not* shipped as a built-in. There's no canonical
// "fff" grep tool with a known argument shape — the most popular
// binary named `fff` is the bash file-manager
// (https://github.com/dylanaraps/fff), which is interactive and
// doesn't accept a search pattern as an argument. Wiring a guess
// here would silently return zero results for that flavour. Users
// who have their own `fff` (or any other custom tool) should
// register it from init.ts where the exact CLI is known. The
// starter init.ts template documents the pattern.

registerProvider({
  name: "grep",
  priority: -4,
  isAvailable: async ({ machine, cwd }) => (await machine.run("grep", ["--version"], cwd)).code === 0,
  search: async (query, opts) => {
    const { cwd, maxResults } = opts;
    const args = grepArgs(query, opts);
    const r = await runSearch("grep", args, cwd, opts);
    if (r.code === 0 || r.code === 1) {
      // grep emits `path:line:content` (no column; it defaults to 1).
      return parseGrepOutput(r.stdout, maxResults, (msg) => editor.debug(msg), false) as GrepMatch[];
    }
    throw new Error(`grep exited with code ${r.code}: ${r.stderr}`);
  },
});

/** The providers above: they run everything on the machine they are given.
 *  One registered from init.ts may predate that and spawn on its own, on the
 *  active window's machine. */
const builtinProviders = new Set(providers);

// ── Wiring ──────────────────────────────────────────────────────

function badgeFor(source: ScopeId | undefined): string {
  if (!source || source === "files") return "";
  const def = SCOPES.find((s) => s.id === source);
  return def?.badge ? `[${def.badge}] ` : "";
}

/** What a match is, among all of them: the same hit can come from two
 *  scopes (an open buffer and the file on disk), two terminals can share a
 *  name, and two workspaces can hold the same relative path. */
function matchId(match: GrepMatch): string {
  const ws = match.workspace && !match.workspace.current ? `${match.workspace.id}|` : "";
  const where = match.openPath ?? match.file;
  const buffer = match.bufferId !== undefined ? `#${match.bufferId}` : "";
  return `${ws}${match.source ?? ""}:${where}${buffer}:${match.line}:${match.column}`;
}

/** The file a match opens: its own `openPath`, else its row's path —
 *  relative to the editor's cwd in this workspace, so resolved against
 *  its workspace's root in another. */
function openPathOf(match: GrepMatch): string {
  if (match.openPath !== undefined) return match.openPath;
  const ws = match.workspace;
  if (!ws || ws.current || editor.pathIsAbsolute(match.file)) return match.file;
  return editor.pathJoin(ws.root, match.file);
}

/** A group's header row under "All workspaces": `web · 3 matches`. */
function headingLabel(ws: Workspace, count: number): string {
  const n = count === 1
    ? editor.t("group.match_count_one")
    : editor.t("group.match_count", { count: String(count) });
  return `── ${ws.name} · ${n}`;
}

/** Window ids top to bottom as the dock lists them, when the Orchestrator
 *  is loaded; with it, the workspaces' dock names too. */
function dockOrder(): { windowId: number; name: string }[] {
  const orchestrator = editor.getPluginApi("orchestrator") as
    | { workspaceOrder?: () => { windowId: number; name: string }[] }
    | null;
  try {
    return orchestrator?.workspaceOrder?.() ?? [];
  } catch (e) {
    editor.debug(`[live_grep] workspaceOrder: ${e}`);
    return [];
  }
}

/** Go to workspace `ws` the way the dock does: an animated switch, wiping
 *  in from the edge its row lies toward. */
function switchToWorkspace(ws: Workspace): void {
  const order = dockOrder().map((w) => w.windowId);
  const from = order.indexOf(editor.activeWindow());
  const to = order.indexOf(ws.id);
  editor.setActiveWindowAnimated(ws.id, from >= 0 && to >= 0 && to < from ? "top" : "bottom");
}

const finder = new Finder<GrepMatch>(editor, {
  id: "live-grep",
  format: (match) => {
    if (match.heading !== undefined && match.workspace) {
      return {
        id: `workspace:${match.workspace.id}`,
        label: headingLabel(match.workspace, match.heading),
        heading: true,
      };
    }
    return {
      id: matchId(match),
      label: `${badgeFor(match.source)}${match.file}:${match.line}`,
      description:
        match.content.length > 60
          ? match.content.substring(0, 57).trim() + "..."
          : match.content.trim(),
      // A line on a terminal's screen is in no file: picking it shows the
      // terminal (`onSelect`), and there is nothing to preview
      location:
        match.bufferId === undefined
          ? { file: openPathOf(match), line: match.line, column: match.column }
          : undefined,
      preview: match.preview,
    };
  },
  onClose: () => {
    overlayActive = false;
  },
  // Override the Finder's default "open file + status: Opened X"
  // so we can surface the resume shortcut here. The shortcut is
  // hidden inside the overlay (it can't apply while the overlay
  // is open), but it's exactly what the user needs to know once
  // they've jumped to a result and want to keep browsing.
  onSelect: (item, entry) => {
    // Another workspace's hit: go there first, then land on it as in this
    // one. A header row just goes to its workspace.
    if (item.workspace && !item.workspace.current) switchToWorkspace(item.workspace);
    if (item.heading !== undefined) {
      // nothing to open
    } else if (item.bufferId !== undefined) {
      editor.showBuffer(item.bufferId);
    } else if (entry.location) {
      editor.openFile(
        entry.location.file,
        entry.location.line,
        entry.location.column
      );
    }
    const resumeKey = editor.getKeybindingLabel("resume_live_grep", "normal");
    if (resumeKey) {
      editor.setStatus(`${resumeKey} to resume search`);
    }
  },
  preview: false,
  maxResults: MAX_RESULTS,
});

// The Quickfix list is just another "list of locations" surface, so it
// rides the same Finder panel abstraction as Diagnostics and Find
// References (dockable via `useUtilityDock`, Enter → openFile for free).
// Exporting hands it a static snapshot of the current matches; the
// bespoke Rust quickfix buffer it replaced is gone.
const quickfixFinder = new Finder<GrepMatch>(editor, {
  id: "quickfix",
  format: (match) => ({
    id: matchId(match),
    label: `${match.workspace && !match.workspace.current ? `${match.workspace.name}: ` : ""}${match.file}:${match.line}:${match.column}`,
    description: match.content.trim(),
    location: {
      file: openPathOf(match),
      line: match.line,
      column: match.column,
    },
    preview: match.preview,
  }),
  useUtilityDock: true,
  // Keep the Quickfix list docked when jumping to an entry — like Vim's
  // quickfix and VS Code's results list — so the user can step through
  // matches. (Find References / Diagnostics keep the default close.)
  closeOnSelect: false,
  // As in the overlay: another workspace's entry goes to that workspace
  // first, and a line on a terminal's screen shows the terminal.
  onSelect: (item, entry) => {
    if (item.workspace && item.workspace.id !== editor.activeWindow()) {
      switchToWorkspace(item.workspace);
    }
    if (item.bufferId !== undefined) {
      editor.showBuffer(item.bufferId);
    } else if (entry.location) {
      editor.openFile(entry.location.file, entry.location.line, entry.location.column);
      editor.setStatus(`Jumped to ${entry.location.file}:${entry.location.line}`);
    }
  },
});

// Snapshot the current Live Grep results into the Quickfix dock panel.
// Bound to the `live_grep_export_quickfix` keybinding (Alt+M / Alt+Q,
// when=prompt) — a plain plugin action now that the Rust action is gone.
function exportQuickfix(): void {
  if (!overlayActive) return;
  if (lastResults.length === 0) {
    editor.setStatus("No Live Grep results to export");
    return;
  }
  const query = lastQuery;
  const matches = lastResults;
  // Dismiss the host overlay first so the panel opens against the editor
  // pane (which is then routed into the dock), not behind the overlay.
  // `cancelPrompt` is the same teardown Escape triggers; the plugin's
  // own prompt state is cleared via the resulting `prompt_cancelled`
  // hook.
  editor.cancelPrompt();
  void quickfixFinder.panel({
    title: `Quickfix: ${query} (${matches.length} matches)`,
    items: matches,
  });
}
registerHandler("live_grep_export_quickfix", exportQuickfix);
// Register the action→handler mapping so the `live_grep_export_quickfix`
// keybinding (a PluginAction now) resolves across the plugin boundary.
// A never-activated context keeps it out of the palette — it's only
// meaningful from inside the Live Grep overlay.
editor.registerCommand(
  "Live Grep: Export to Quickfix (internal)",
  "",
  "live_grep_export_quickfix",
  "live-grep-internal"
);

/**
 * Switch to the next *available* registered provider, in priority
 * order, wrapping at the end. Unavailable providers (those whose
 * `isAvailable()` returns false right now) are skipped — pressing
 * the cycle key never lands on a backend that can't actually run.
 *
 * Side effects: updates `cachedSelected` so the next search uses
 * the new provider, fires a status message naming the new
 * provider, and re-runs the current query (via the prompt-changed
 * hook the Finder is already listening for).
 */
async function cycleProvider(): Promise<void> {
  if (providers.length === 0) {
    editor.setStatus("Live Grep: no providers registered");
    return;
  }
  // Find the position to start scanning from. If a provider is
  // currently cached, start *after* it so we genuinely move on; if
  // not, start from the top of the list.
  const currentIdx =
    cachedSelected != null ? providers.indexOf(cachedSelected) : -1;
  // Walk the full list once (mod len), skipping any provider whose
  // probe says unavailable. If we wrap back to where we started
  // without finding a different available provider, surface a
  // status message and leave the selection alone.
  for (let step = 1; step <= providers.length; step++) {
    const idx = (currentIdx + step + providers.length) % providers.length;
    const candidate = providers[idx];
    if (candidate === cachedSelected) {
      // Looped past the start without finding anything else
      // available; only the current one is usable.
      editor.setStatus(
        `Live Grep: no other available providers (still on ${candidate.name})`
      );
      return;
    }
    if (!(await probeProvider(candidate))) continue;
    cachedSelected = candidate;
    // Reflect the new provider in the toolbar's dropdown immediately —
    // the status row gets clobbered by the search result count, but the
    // dropdown stays put. The dropdown's selection is host-owned once
    // shown, so it is set directly rather than re-seeded from the spec.
    syncProviderDropdown(candidate);
    updateOverlayTitle(candidate);
    // Re-run the current query through the new provider so the
    // result list updates without the user having to type a
    // throwaway character. `refresh()` itself sets status to
    // "Found N matches" — we want the user to see the *cycle*
    // result, so re-set the status afterwards.
    await finder.refresh();
    editor.setStatus(`Live Grep: switched to ${candidate.name}`);
    return;
  }
  editor.setStatus("Live Grep: no available providers");
}
registerHandler("live_grep_cycle_provider", cycleProvider);
// `registerHandler` only sets a globalThis function — to make the
// editor's `execute_action` path find it across the plugin-context
// boundary the action also has to live in the registered-actions
// table. `registerCommand` is the public-facing mechanism that
// inserts that entry. Doubles as a palette-discoverable command.
editor.registerCommand(
  "%cmd.live_grep_cycle_provider",
  "%cmd.live_grep_cycle_provider_desc",
  "live_grep_cycle_provider",
  null
);

// Strip ANSI escape sequences so terminal scrollback (stored with
// colour codes in the backing file) shows as plain text in results.
function stripAnsi(s: string): string {
  return s
    // CSI … final byte (colours, cursor moves, etc.)
    .replace(/\x1b\[[0-9;?]*[ -/]*[@-~]/g, "")
    // OSC … terminated by BEL or ST
    .replace(/\x1b\][^\x07\x1b]*(?:\x07|\x1b\\)/g, "")
    // Remaining two-byte escapes
    .replace(/\x1b[@-Z\\-_]/g, "");
}

/** One workspace's content besides its files on disk, for a search of it. */
interface WorkspaceContent {
  workspace: Workspace;
  /** Its open file buffers. */
  buffers: { bufferId: number; path: string; modified: boolean }[];
  /** Its terminals' screens. */
  screens: TerminalScreen[];
  /** The directory of its terminals' backing files. */
  terminalDir: string;
}

/** What `workspace` has open: the active window's, or — for another
 *  workspace — that window's, through the same calls with its id. A
 *  workspace not opened yet this session has no buffers or terminals
 *  running; its terminals' history is still in its directory. */
async function workspaceContent(workspace: Workspace): Promise<WorkspaceContent> {
  // No argument means the active window
  const id: [] | [number] = workspace.current ? [] : [workspace.id];
  return {
    workspace,
    // Virtual buffers (terminals, panels) and bufferless/unnamed buffers
    // have no on-disk file to navigate to.
    buffers: editor
      .listBuffers(...id)
      .filter((b) => !b.is_virtual && b.path)
      .map((b) => ({ bufferId: b.id, path: b.path as string, modified: b.modified })),
    screens: scopeEnabled.terminals ? await editor.getTerminalScreens(...id) : [],
    terminalDir: editor.getTerminalDir(...id),
  };
}

/** Search terminal scrollback. Terminal backing files live under the
 *  workspace's terminal subdir (`getTerminalDir()` →
 *  `<data_dir>/terminals/<encoded-cwd>/`) — open terminals stream their
 *  scrollback there live, and closed terminals are retained there too
 *  (renamed `*-closed-*.txt`). Scoping to that subdir keeps the search to
 *  *this* project / worktree; "All workspaces" searches each workspace's.
 *  We grep it with rg (falling back to grep), then strip ANSI for display.
 *  Opening a hit opens the backing file at the matched line; its row is
 *  labelled with the terminal's name when the terminal is open, else with
 *  the backing file's name. Those files
 *  are written as lines scroll off, and hold the screen only as of the last
 *  checkpoint, so what is on an open terminal's screen now is matched as it
 *  is in memory (`getTerminalScreens`, which writes nothing); opening such a
 *  hit shows the terminal. */
async function searchTerminals(
  query: string,
  content: WorkspaceContent,
  limit: number,
  cancellation?: SearchCancellation,
): Promise<GrepMatch[]> {
  if (limit <= 0) return [];
  const onScreen: GrepMatch[] = [];
  const matchCol = buildLineMatcher(query);
  const screens = content.screens;
  for (const screen of screens) {
    const name = screen.name || "terminal";
    screen.lines.forEach((line, i) => {
      const column = matchCol(line);
      if (column > 0 && onScreen.length < limit) {
        onScreen.push({
          file: name,
          line: i + 1,
          column,
          content: line,
          source: "terminals",
          bufferId: screen.bufferId,
        });
      }
    });
  }
  limit -= onScreen.length;
  if (limit <= 0) return onScreen;
  // The terminal directory is in the editor's data dir, on this machine
  if (!content.terminalDir || !editor.fileExists(editor.localPath(content.terminalDir))) {
    return onScreen;
  }
  let raw: GrepMatch[] = [];
  // The backing files as text (they hold ANSI escapes), only the rendered
  // `.txt` ones — not the raw `.log` replay logs, which would double every
  // hit — and nothing left out as ignored.
  const opts: GrepArgOpts = {
    maxResults: limit,
    includeIgnored: true,
    wholeWord: searchModes.word,
    regex: searchModes.regex,
    caseSensitive: searchModes.case,
    text: true,
    include: "*.txt",
    paths: [content.terminalDir],
  };
  // The backing files are in the editor's data dir: always on this computer,
  // whichever machine the workspace's own files are on.
  const hostSearch = (cmd: string, args: string[]) => {
    const process = editor.spawnHostProcess(cmd, args, content.terminalDir);
    cancellation?.onCancel(() => process.kill());
    return process;
  };
  try {
    const r = await hostSearch("rg", rgArgs(query, opts));
    if (r.exit_code === 0) {
      raw = parseGrepOutput(r.stdout, limit, (m) => editor.debug(m)) as GrepMatch[];
    } else if (r.exit_code !== 1) {
      // rg missing or path error → fall back to grep.
      const g = await hostSearch("grep", grepArgs(query, opts));
      if (g.exit_code === 0) {
        raw = parseGrepOutput(g.stdout, limit, (m) => editor.debug(m), false) as GrepMatch[];
      }
    }
  } catch (e) {
    editor.debug(`[live_grep:terminals] ${e}`);
  }
  // A checkpoint leaves a terminal's screen in its backing file too, after
  // the scrollback: a line found on the screen isn't listed again from it
  const baseName = (path: string) => path.slice(path.lastIndexOf("/") + 1);
  const shown = new Map(
    screens
      .filter((s) => s.file !== "")
      .map((s) => [baseName(s.file), new Set(s.lines)] as const),
  );
  const fromFiles = raw
    .map((m) => ({ ...m, source: "terminals" as const, content: stripAnsi(m.content) }))
    .filter((m) => !shown.get(baseName(m.file))?.has(m.content.trimEnd()))
    .map((m) => ({
      ...m,
      file: terminalRowName(m.file, screens),
      openPath: m.file,
    }));
  return onScreen.concat(fromFiles.slice(0, limit));
}

/** Search the text of a workspace's open, modified file buffers.
 *  Scoped to *modified* buffers on purpose: unmodified buffers are
 *  already covered by the on-disk file scan, so this surfaces exactly
 *  the unsaved edits a disk grep would miss, without double-reporting.
 *  The editor searches each buffer as it is (`searchBuffer`), however
 *  large, with the same query language as its own search; a row per
 *  match, at its byte column. */
async function searchOpenBuffers(
  query: string,
  content: WorkspaceContent,
  limit: number,
  includeUnmodified: boolean,
  cancellation?: SearchCancellation,
): Promise<GrepMatch[]> {
  if (limit <= 0) return [];
  const out: GrepMatch[] = [];
  const cwd = content.workspace.root;
  for (const b of content.buffers) {
    if (out.length >= limit) break;
    // When the file scan is also running, restrict to *modified* buffers
    // so saved buffers aren't double-reported (the disk grep already covers
    // them); when buffers is the only file-backed scope, search every open
    // buffer so the user actually finds matches.
    if (!includeUnmodified && !b.modified) continue;
    if (cancellation?.cancelled) break;
    const search = editor.searchBuffer(b.bufferId, query, {
      fixedString: !searchModes.regex,
      caseSensitive: searchModes.case,
      wholeWords: searchModes.word,
      maxResults: limit - out.length,
    });
    // A newer query (or closing the overlay) stops it.
    cancellation?.onCancel(() => search.cancel());
    let matches: Awaited<typeof search>;
    try {
      matches = await search;
    } catch {
      // An invalid regex matches nothing here; the provider scopes
      // surface the error.
      continue;
    }
    // Named like the file scan's rows: relative to the cwd when under it.
    const file = relativeUnder(cwd, b.path) || b.path;
    for (const m of matches) {
      out.push({ file, line: m.line, column: m.column, content: m.context, source: "buffers", openPath: b.path });
    }
  }
  return out;
}

function severityLabel(sev: number | null | undefined): string {
  switch (sev) {
    case 1: return "error";
    case 2: return "warning";
    case 3: return "info";
    case 4: return "hint";
    default: return "diagnostic";
  }
}

/** Search active LSP diagnostics by message text. Matches jump to the
 *  diagnostic's range like any other location. */
function searchDiagnostics(query: string, limit: number): GrepMatch[] {
  if (limit <= 0) return [];
  const out: GrepMatch[] = [];
  const matchCol = buildLineMatcher(query);
  for (const d of editor.getAllDiagnostics()) {
    if (out.length >= limit) break;
    if (matchCol(d.message) <= 0) continue;
    const file = d.uri.startsWith("file://") ? decodeURIComponent(d.uri.slice("file://".length)) : d.uri;
    out.push({
      file,
      line: (d.range?.start?.line ?? 0) + 1,
      column: (d.range?.start?.character ?? 0) + 1,
      content: `${severityLabel(d.severity)}: ${d.message}`,
      source: "diagnostics",
    });
  }
  return out;
}

/** `file_explorer.custom_ignore_patterns`, read per search so a settings
 *  change applies to the next keystroke. Non-strings are dropped. */
function customIgnorePatterns(): string[] {
  const patterns = editor.getConfig()?.file_explorer?.custom_ignore_patterns;
  return Array.isArray(patterns) ? patterns.filter((p): p is string => typeof p === "string") : [];
}

/** The provider to search another workspace's files with: the first that
 *  can run on that workspace's machine, the one selected here tried first.
 *  On a machine other than the active window's, only the built-in ones,
 *  which run where they are told. Decided once per workspace per overlay. */
async function providerForOther(workspace: Workspace, ctx: ProviderContext): Promise<LiveGrepProvider | null> {
  const known = otherProviders.get(workspace.id);
  if (known !== undefined) return known;
  const selected = cachedSelected !== undefined ? cachedSelected : await selectProvider();
  const sameMachine = !workspace.remote && !currentWorkspace().remote;
  let chosen: LiveGrepProvider | null = null;
  for (const p of selected ? [selected, ...providers.filter((q) => q !== selected)] : providers) {
    if (!sameMachine && !builtinProviders.has(p)) continue;
    if (await canRun(p, ctx)) {
      chosen = p;
      break;
    }
  }
  otherProviders.set(workspace.id, chosen);
  return chosen;
}

/** `providerForOther`'s answers, by window, for one overlay. */
const otherProviders = new Map<number, LiveGrepProvider | null>();

/** The window list with every saved workspace in it, read once per
 *  overlay rather than per keystroke. */
let workspacesLoaded: Promise<void> | null = null;

// Run the project-file grep for the enabled file-backed scopes
// (`files` / `ignored`) in `workspace`'s root. Returns null when no
// provider is available so the caller can decide whether that's fatal
// (no other scope on) or merely a skipped source.
async function searchFiles(
  query: string,
  workspace: Workspace,
  cancellation?: SearchCancellation,
): Promise<GrepMatch[] | null> {
  let machine: FreshMachine;
  try {
    machine = await machines.get(workspace.id);
  } catch (e) {
    // A workspace that closed under the search has nothing to search.
    editor.debug(`[live_grep] no machine for workspace ${workspace.id}: ${e}`);
    return workspace.current ? null : [];
  }
  const ctx = { machine, cwd: workspace.root };
  const provider = workspace.current ? await selectProvider() : await providerForOther(workspace, ctx);
  if (!provider) return null;
  try {
    const results = await provider.search(query, {
      ...ctx,
      cancellation,
      maxResults: MAX_RESULTS,
      includeIgnored: scopeEnabled.ignored,
      ignorePatterns: scopeEnabled.ignored ? [] : customIgnorePatterns(),
      wholeWord: searchModes.word,
      regex: searchModes.regex,
      caseSensitive: searchModes.case,
    });
    return results.map((m) => ({ ...m, source: "files" as const }));
  } catch (e) {
    // A killed search fails with exit -1; it was superseded, not broken.
    if (cancellation?.cancelled) return [];
    editor.error(`[live_grep:${provider.name}] ${e}`);
    // Another workspace's failure leaves its files out, not the search.
    if (!workspace.current) return [];
    throw new Error(`${provider.name}: ${e instanceof Error ? e.message : String(e)}`);
  }
}

// Fan the query out across every enabled scope in one workspace and
// merge into one capped, tagged result list. Order is files → buffers →
// terminals → diagnostics so the most common hits lead.
async function searchWorkspace(
  query: string,
  content: WorkspaceContent,
  limit: number,
  cancellation?: SearchCancellation,
): Promise<GrepMatch[]> {
  const { workspace } = content;
  const results: GrepMatch[] = [];
  const remaining = () => limit - results.length;

  if (scopeEnabled.files || scopeEnabled.ignored) {
    const fileMatches = await searchFiles(query, workspace, cancellation);
    if (fileMatches === null) {
      // No grep backend. Only fatal if there's nothing else to search.
      const otherScopes = scopeEnabled.buffers || scopeEnabled.terminals || scopeEnabled.diagnostics;
      if (workspace.current && !otherScopes && !scopeEnabled.workspaces) {
        throw new Error(
          "no search backend available — install ripgrep, or register a provider via init.ts (`editor.getPluginApi(\"live-grep\")?.registerProvider(...)`)."
        );
      }
    } else {
      // A file open with unsaved edits is searched as its buffer below;
      // the disk's rows for it point at lines that are no longer there.
      const unsaved = new Set(
        scopeEnabled.buffers ? content.buffers.filter((b) => b.modified).map((b) => b.path) : [],
      );
      for (const m of fileMatches) {
        if (results.length >= limit) break;
        if (unsaved.has(editor.pathJoin(workspace.root, m.file))) continue;
        results.push(m);
      }
    }
  }

  if (scopeEnabled.buffers && remaining() > 0) {
    const filesActive = scopeEnabled.files || scopeEnabled.ignored;
    results.push(...await searchOpenBuffers(query, content, remaining(), !filesActive, cancellation));
  }

  if (scopeEnabled.terminals && remaining() > 0) {
    results.push(...await searchTerminals(query, content, remaining(), cancellation));
  }

  // Diagnostics are the current workspace's language servers' only.
  if (scopeEnabled.diagnostics && workspace.current && remaining() > 0) {
    results.push(...searchDiagnostics(query, remaining()));
  }

  return results;
}

/** The workspace the overlay was opened in. */
function currentWorkspace(): Workspace {
  const id = editor.activeWindow();
  const here = editor.listWindows().filter((w) => w.id === id);
  return orderWorkspaces({ id, root: editor.getCwd() }, here, [])[0];
}

/** Workspaces searched at once under "All workspaces", besides the current
 *  one: each runs a search, and a terminal-history grep, per keystroke. */
const WORKSPACES_AT_ONCE = 4;

/** Whether the preview shows what matched for `match`, in another workspace
 *  than `current`. The preview reads files through the current workspace's
 *  machine, so it cannot show one on another machine; nor an unsaved
 *  buffer's text, only its file on disk. A terminal's history is on this
 *  computer. */
function previewable(match: GrepMatch, current: Workspace): boolean {
  if (current.remote) return false;
  if (match.source === "terminals") return true;
  return match.source !== "buffers" && !match.workspace?.remote;
}

/** "All workspaces": each workspace's matches as one group under a header
 *  row — the current workspace first, then the others in dock order (window
 *  order without the Orchestrator), each searched on its own machine. A
 *  workspace with no matches is left out. */
async function searchAllWorkspaces(query: string, cancellation?: SearchCancellation): Promise<GrepMatch[]> {
  // The dock lists workspaces not opened yet this session; so does this.
  workspacesLoaded ??= editor.loadWorkspaces();
  await workspacesLoaded;
  const [current, ...others] = orderWorkspaces(
    { id: editor.activeWindow(), root: editor.getCwd() },
    editor.listWindows(),
    dockOrder(),
  );
  const own = await searchWorkspace(query, await workspaceContent(current), MAX_RESULTS, cancellation);
  // The others share what is left of the cap, a few side by side, started in
  // dock order; none is started once the cap is filled. Their groups keep
  // dock order, cut at the cap in that order.
  const theirs: GrepMatch[][] = others.map(() => []);
  let found = own.length;
  let next = 0;
  const searchNext = async (): Promise<void> => {
    while (next < others.length && found < MAX_RESULTS && !cancellation?.cancelled) {
      const i = next++;
      theirs[i] = await searchWorkspace(query, await workspaceContent(others[i]), MAX_RESULTS - found, cancellation);
      found += theirs[i].length;
    }
  };
  await Promise.all(Array.from({ length: Math.min(WORKSPACES_AT_ONCE, others.length) }, searchNext));
  const groups: { workspace: Workspace; matches: GrepMatch[] }[] = [{ workspace: current, matches: own }];
  found = own.length;
  theirs.forEach((matches, i) => {
    const kept = matches.slice(0, MAX_RESULTS - found);
    groups.push({ workspace: others[i], matches: kept });
    found += kept.length;
  });
  return groupByWorkspace<GrepMatch>(
    groups,
    (workspace, count) => ({ file: "", line: 0, column: 0, content: "", workspace, heading: count }),
    (match, workspace) => ({
      ...match,
      workspace,
      ...(workspace.current ? {} : { preview: previewable({ ...match, workspace }, current) }),
    }),
  );
}

async function search(query: string, cancellation?: SearchCancellation): Promise<GrepMatch[]> {
  lastQuery = query;
  const wasTruncated = lastSearchTruncated;
  const results = scopeEnabled.workspaces
    ? await searchAllWorkspaces(query, cancellation)
    : await searchWorkspace(query, await workspaceContent(currentWorkspace()), MAX_RESULTS, cancellation);
  const matches = results.filter((m) => m.heading === undefined);

  lastSearchTruncated = matches.length >= MAX_RESULTS;
  // Refresh the toolbar whenever the truncation indicator changes so
  // it appears (or disappears) alongside the new results.
  if (lastSearchTruncated !== wasTruncated) {
    updateOverlayTitle(cachedSelected ?? null);
  }
  lastResults = matches;
  return results;
}

// Scope/mode toggling is host-owned: the host flips the toggle's checked
// state (on click, Space on the focused toggle, or the Alt+… shortcuts) and
// emits a `widget_event`; we react here by syncing the scope/mode set,
// refreshing the toolbar, and re-running the search.
editor.on("widget_event", (args) => {
  if (!overlayActive) return;
  // The provider dropdown (click / Enter / arrows) picks the search backend.
  if (args.event_type === "change" && args.widget_key === "provider") {
    const payload = args.payload as { index?: number } | undefined;
    if (typeof payload?.index === "number") void pickProvider(payload.index);
    return;
  }
  if (args.event_type !== "toggle") return;
  const payload = args.payload as { checked?: boolean } | undefined;
  const scope = SCOPES.find((s) => s.id === args.widget_key);
  const mode = MODES.find((m) => m.key === args.widget_key);
  let label: string;
  let on: boolean;
  if (scope) {
    on = payload?.checked ?? !scopeEnabled[scope.id];
    scopeEnabled[scope.id] = on;
    label = editor.t(scope.labelKey);
  } else if (mode) {
    on = payload?.checked ?? !searchModes[mode.id];
    searchModes[mode.id] = on;
    label = editor.t(mode.labelKey);
  } else {
    return;
  }
  // Rebuild the toolbar so the provider row tracks the file scopes. The host already flipped the toggle visual, but scopeEnabled/
  // searchModes were just synced above, so the rebuilt spec keeps the same
  // checked state (and toolbar_focus persists across setPromptToolbar).
  updateOverlayTitle(cachedSelected ?? null);
  void finder.refresh();
  editor.setStatus(`Search: ${label} ${on ? "on" : "off"}`);
});

// The per-toggle Alt+… shortcuts (and palette entries) just route through the
// host toggle path, so click / Space / shortcut all converge on the same
// widget_event above. The action's keybinding label is what the toolbar
// shows as each toggle's inline accelerator. Sources are keyed by scope id;
// modes by their widget key.
for (const s of SCOPES) {
  registerHandler(s.action, () => {
    editor.toggleOverlayToolbarWidget(s.id);
  });
  editor.registerCommand(`%cmd.${s.action}`, `%cmd.${s.action}_desc`, s.action, null);
}
for (const m of MODES) {
  registerHandler(m.action, () => {
    editor.toggleOverlayToolbarWidget(m.key);
  });
  editor.registerCommand(`%cmd.${m.action}`, `%cmd.${m.action}_desc`, m.action, null);
}

// Shared open flow for both fresh start and resume. `initialQuery`
// pre-fills the input (Resume passes the last query) — Resume is just the
// same flow with prepopulated data, no bespoke overlay.
function openLiveGrep(initialQuery: string): void {
  overlayActive = true;
  workspacesLoaded = null;
  otherProviders.clear();
  finder.prompt({
    title: queryLabel(),
    source: {
      mode: "search",
      search,
      debounceMs: 150,
      minQueryLength: 2,
    },
    floatingOverlay: true,
    ...(initialQuery ? { initialQuery } : {}),
  });
  // Results, preview and toolbar all want the room: size the card on the
  // whole screen (90%, over the dock), the way Settings is.
  editor.setPromptFullscreen(true);
  // Pre-populate the overlay's frame title with the cached
  // provider name (if any) before the user types — avoids the
  // brief "Live Grep" → "Live Grep · rg" flash when the
  // first search resolves selectProvider().
  // Probe every provider in the background so the dropdown can leave out
  // the ones that cannot run.
  void probeProviders();
  if (cachedSelected) {
    updateOverlayTitle(cachedSelected);
  } else {
    // Kick off provider probing in the background so the title
    // updates as soon as the first available probe resolves,
    // rather than waiting for the first keystroke.
    void selectProvider();
  }
}

function start_live_grep(): void {
  openLiveGrep("");
}
registerHandler("start_live_grep", start_live_grep);

// Resume: identical flow, just seeded with the last query so the user
// picks up where they left off — same overlay, same toolbar, same scopes.
function resume_live_grep(): void {
  openLiveGrep(lastQuery);
}
registerHandler("resume_live_grep", resume_live_grep);
// Register the action→plugin-context mapping so the core `resume_live_grep`
// action (Alt+R / the built-in "Resume Live Grep" palette command) resolves
// to this handler. A never-activated custom context keeps it out of the
// palette so it doesn't duplicate the core entry.
editor.registerCommand(
  "Live Grep: Resume (internal)",
  "",
  "resume_live_grep",
  "live-grep-internal"
);

editor.registerCommand(
  "%cmd.live_grep",
  "%cmd.live_grep_desc",
  "start_live_grep",
  null
);

editor.exportPluginApi("live-grep", {
  registerProvider,
  unregisterProvider,
  listProviders(): { name: string; priority: number }[] {
    return providers.map((p) => ({
      name: p.name,
      priority: p.priority ?? 0,
    }));
  },
  resetSelection(): void {
    cachedSelected = undefined;
  },
} satisfies LiveGrepApi);

editor.debug("Live Grep plugin loaded (provider registry)");
