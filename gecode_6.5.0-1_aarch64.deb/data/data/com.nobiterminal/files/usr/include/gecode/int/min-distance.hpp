/* -*- mode: C++; c-basic-offset: 2; indent-tabs-mode: nil -*- */
/*
 *  Main authors:
 *     Mikael Zayenz Lagerkvist <lagerkvist@gecode.dev>
 *
 *  Copyright:
 *     Mikael Zayenz Lagerkvist, 2026
 *
 *  This file is part of Gecode, the generic constraint
 *  development environment:
 *     http://www.gecode.dev
 *
 *  Permission is hereby granted, free of charge, to any person obtaining
 *  a copy of this software and associated documentation files (the
 *  "Software"), to deal in the Software without restriction, including
 *  without limitation the rights to use, copy, modify, merge, publish,
 *  distribute, sublicense, and/or sell copies of the Software, and to
 *  permit persons to whom the Software is furnished to do so, subject to
 *  the following conditions:
 *
 *  The above copyright notice and this permission notice shall be
 *  included in all copies or substantial portions of the Software.
 *
 *  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 *  NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
 *  LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
 *  OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
 *  WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 */


#ifndef GECODE_INT_MIN_DISTANCE_HPP
#define GECODE_INT_MIN_DISTANCE_HPP

namespace Gecode {

  forceinline int
  IntDistance::size(void) const {
    return static_cast<const Data*>(object())->n;
  }

  forceinline int
  IntDistance::operator ()(int a, int b) const {
    const Data& d = *static_cast<const Data*>(object());
    assert((a >= 0) && (a < d.n) && (b >= 0) && (b < d.n));
    if (d.matrix)
      return d.matrix[a*d.n+b];
    int v = d.function(a,b);
    Int::Limits::nonnegative(v,"IntDistance::operator()");
    if ((a == b) && (v != 0))
      throw Int::IllegalOperation("IntDistance::operator()");
    return v;
  }

}

#endif

// STATISTICS: int-post
